#include "userprog/syscall.h"
#include <stdio.h>
#include <syscall-nr.h>
#include "threads/interrupt.h"
#include "threads/thread.h"
#include "devices/shutdown.h"
#include "userprog/process.h"
#include "userprog/exception.h"
#include "devices/input.h"
#include "threads/vaddr.h"
#include "lib/string.h"
#include "lib/user/syscall.h"
#include "threads/vaddr.h"
#define CHECK_S false  ////////PROJECT_#1

static void syscall_handler (struct intr_frame *);

void
syscall_init (void) 
{
  if(CHECK_S) printf("~~syscall_init 1\n");
  intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
  if(CHECK_S) printf("~~syscall_init 2(END)\n");
}

static void
syscall_handler (struct intr_frame *f UNUSED) 
{

  int *sys_n;
  sys_n = (int*)f->esp;
//  if (CHECK_S) printf("~~syscall_handler 1\n");
  
  if (*sys_n == SYS_HALT) halt();
  else if (*sys_n == SYS_EXIT) {
	if(!is_user_vaddr(f->esp+4)) {
		f->eax = -1;
		exit(-1);
		}
	else {
		f->eax = *(int*)(f->esp+4);
		exit(*(int*)(f->esp+4));
	}
  }
  else if (*sys_n == SYS_EXEC){
	f->eax = exec(*(char**)(f->esp+4));
  }
  else if (*sys_n == SYS_WAIT){
	f->eax = wait(*(int*)(f->esp+4));
  }
  else if (*sys_n == SYS_READ){
	f->eax = read(*(int*)(f->esp+4), *(void**)(f->esp+8), *(unsigned*)(f->esp+12));
  }
  else if (*sys_n == SYS_WRITE){
	f->eax = write(*(int*)(f->esp+4), *(void**)(f->esp+8), *(unsigned*)(f->esp+12));
  }
  else if (*sys_n == SYS_PIBO){
	f->eax = pibonacci(*(int*)(f->esp+4));
  }
  else if (*sys_n == SYS_SUM_FOUR){
	f->eax = sum_of_four_integers(*(int*)(f->esp+4), *(int*)(f->esp+8), *(int*)(f->esp+12) , *(int*)(f->esp+16));
  }

//  if(CHECK_S) printf("~~syscall_handler 2(END)\n");
//  printf ("system call!\n");
//  thread_exit ();
}

void halt(void){
	shutdown_power_off();
}

int read(int fd, void *buffer, unsigned size){
	int k=0;
	if(CHECK_S) printf("~~read 1\n");
	if(fd == 0){
		for(k = 0; k<(int)size; k++){
			*((char*)buffer+k)= input_getc();
			if(*((char*)buffer+k) == '\0') {
				if(CHECK_S) printf("~~read 2(RETURN) (1)\n");
				return k;
			}
		}
	if(CHECK_S) printf("~~read 2(RETURN) (2)\n");
	return k;
	}
	if(CHECK_S) printf("~~read 2(RETURN) -1\n");
	return -1;
}

int write (int fd, const void *buffer , unsigned size){
	if(CHECK_S) printf("~~wrtie 1\n");
	if(fd == 1){
		putbuf(buffer,size);
		if(CHECK_S) printf("~~write 2(RETURN)\n");
		return (int)size;
	}
	else {
		if(CHECK_S) printf("~~write 2(RETURN) -1\n");
		return -1;
	}
}

void exit(int status){
  struct thread *cur, *cur_parent; //cur : target to exit
  char thread_name_copy[128];	//these
  char *thread_token;		//are
  char *temp_thread_token;	//for print

  cur=thread_current();
  cur_parent=cur->parent;
  if(CHECK_S) printf("~~exit 1\n");

  //print
  strlcpy(thread_name_copy,cur->name,strlen(cur->name)+1);
  thread_token=strtok_r(thread_name_copy," ",&temp_thread_token);
  printf("%s: exit(%d)\n", thread_token, status); //29p,3-3-2

  //settings
  cur_parent->value=status;
  cur_parent->waiting++;	//wait done
  cur->by_exit=1;

  //exit
  if(CHECK_S) printf("~~exit 2 start thread_exit\n");
  thread_exit();

 if(CHECK_S) printf("~~exit 3(END)\n");
}

int exec (const char *cmd_line){
  if(CHECK_S) printf("~~exec 1(RETURN)\n");
  return process_execute(cmd_line);
}

int wait(pid_t pid){
  if(CHECK_S) printf("~~wait 1(RETURN)\n");
  return process_wait(pid);
}

int sum_of_four_integers (int a, int b, int c, int d){
  return a+b+c+d;
}

int pibonacci (int n){
  int a1, a2;
  int i;

  a1=0;
  a2=1;

  for(i=0;i<n;i++){
    a2=a1+a2;
    a1=a2-a1;
  }
  return a1;
}
