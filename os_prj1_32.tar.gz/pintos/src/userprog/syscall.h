#ifndef USERPROG_SYSCALL_H
#define USERPROG_SYSCALL_H

void syscall_init (void);
void halt(void);
int read(int,void*,unsigned);
int write(int,const void*,unsigned);
void exit(int);
int exec(const char*);
int wait(pid_t);
int sum_of_four_integers(int,int,int,int);
int pibonacci(int);
#endif /* userprog/syscall.h */
