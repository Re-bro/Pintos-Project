#include "vm/page.h"
#include <stdio.h>
#include <stdlib.h>
#include <list.h>
#include "filesys/file.h"
#include "threads/thread.h"
#define THREAD_NUM 400		//thread.c

/* thread의 PageTable array
   각 PT[tid]는 tid번 thread의  page table list의 포인터
   각 PT[tid]는 pagee->pelem을 원소로 가짐 */
struct list* PT[THREAD_NUM];

/* 새로운 thread 시작할 때 PT[tid] 개시 */
void init_PT(struct thread* thr){

  int tid=thr->tid;
  static struct list PageTable;

  list_init(&PageTable);
  PT[tid]=&PageTable;
}

/* file을새로 열 때 PT[tid]에 page 추가  */
void add_page_PT(struct file *file, off_t ofs, uint8_t *upage,uint32_t read_bytes, uint32_t zero_bytes, bool writable){

  int tid=thread_current()->tid;
  struct pagee *new;

  new->file=file; new->ofs=ofs; new->upage=upage;
  new->zero=zero_bytes; new->read=read_bytes;
  new->writable=writable;

  list_push_back(&PT[tid], &new->pelem);
 
  return; 
}

/* PT[tid]에서 upage와 일치하는 page 찾기 */
struct pagee* find_page_PT(uint8_t *upage){

  struct list_elem *e;
  int tid=thread_current()->tid;

  for(e=list_begin(&PT[tid]);e!=list_end(&PT[tid]);e=list_next(e)){
    if(upage==list_entry(e,struct pagee,pelem)->upage)
      return list_entry(e,struct pagee,pelem);
  }

  return NULL;
}
