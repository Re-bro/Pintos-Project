#include <list.h>
#include "filesys/file.h"
#include "threads/thread.h"

struct pagee{
  struct list_elem pelem;

  struct file *file;
  off_t ofs;
  uint8_t *upage;
  uint32_t read;
  uint32_t zero;
  bool writable;
}pagee;

void init_PT(struct thread*);
void add_page_PT(struct file*, off_t, uint8_t*, uint32_t, uint32_t, bool);
struct pagee* find_page_PT(uint8_t*); 
