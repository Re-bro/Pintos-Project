////////PROJECT_#1

#include <stdio.h>
#include <stdlib.h>
#include <syscall.h>

int main(int argc, char **argv){

	int a, b, c, d, pibo, sum4;
	
	if (argc!=5){
		printf("Usage : sum n1 n2 n3 n4\n");
		return EXIT_FAILURE;
	}

	a=atoi(argv[1]);
	b=atoi(argv[2]);
	c=atoi(argv[3]);
	d=atoi(argv[4]);

	pibo=pibonacci(a);
	sum4=sum_of_four_integers(a,b,c,d);

	printf("%d %d\n",pibo,sum4);

	return EXIT_SUCCESS;
}
