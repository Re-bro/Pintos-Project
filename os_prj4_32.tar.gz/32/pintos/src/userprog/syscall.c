#include "userprog/syscall.h"
#include <stdio.h>
#include <syscall-nr.h>
#include "threads/interrupt.h"
#include "threads/thread.h"
#include "devices/shutdown.h"
#include "userprog/process.h"
#include "userprog/exception.h"
#include "devices/input.h"
#include "threads/vaddr.h"
#include "lib/string.h"
#include "lib/user/syscall.h"
#include "threads/vaddr.h"
#include "filesys/off_t.h"
#include "filesys/file.h"
#include "filesys/filesys.h"
#include "threads/synch.h"

#define CHECK_S false  ////////PROJECT_#1
int fd;
static void syscall_handler (struct intr_frame *);
struct lock sys_lock;  //project #2
void
syscall_init (void) 
{
  lock_init(&sys_lock);  ///project #2

  intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
}

static void
syscall_handler (struct intr_frame *f UNUSED) 
{

  int *sys_n;
  sys_n = (int*)f->esp;
  if(CHECK_S) printf("\nSYS HANDLER tid %d : ",thread_current()->tid);
 
  if (*sys_n == SYS_HALT) halt();
  else if (*sys_n == SYS_EXIT) {
	if(!is_user_vaddr(f->esp+4)) {
		f->eax = -1;
		exit(-1);
		}
	else {
		f->eax = *(int*)(f->esp+4);
		exit(*(int*)(f->esp+4));
	}
  }
  else if (*sys_n == SYS_EXEC){
	f->eax = exec(*(char**)(f->esp+4));
  }
  else if (*sys_n == SYS_WAIT){
	f->eax = wait(*(int*)(f->esp+4));
  }
  else if (*sys_n == SYS_READ){
	f->eax = read(*(int*)(f->esp+4), *(void**)(f->esp+8), *(unsigned*)(f->esp+12));
  }
  else if (*sys_n == SYS_WRITE){
	f->eax = write(*(int*)(f->esp+4), *(void**)(f->esp+8), *(unsigned*)(f->esp+12));
  }
  else if (*sys_n == SYS_PIBO){
	f->eax = pibonacci(*(int*)(f->esp+4));
  }
  else if (*sys_n == SYS_SUM_FOUR){
	f->eax = sum_of_four_integers(*(int*)(f->esp+4), *(int*)(f->esp+8), *(int*)(f->esp+12) , *(int*)(f->esp+16));
  }
  else if (*sys_n == SYS_CREATE){
	f->eax = create(*(char**)(f->esp+4), *(unsigned*)(f->esp+8));
  }
  else if (*sys_n == SYS_REMOVE){
	f->eax = remove(*(char**)(f->esp+4));
  }
  else if (*sys_n == SYS_OPEN){
	f->eax = open(*(char**)(f->esp+4));
  }
  else if (*sys_n == SYS_CLOSE){
	close(*(int*)(f->esp+4));
  }
  else if (*sys_n == SYS_FILESIZE){
	f->eax = filesize(*(int*)(f->esp+4));
  }
  else if (*sys_n == SYS_SEEK){
	seek(*(int*)(f->esp+4), *(unsigned*)(f->esp+8));
  }
  else if (*sys_n == SYS_TELL){
	f->eax = tell(*(int*)(f->esp+4));
  }

}

void halt(void){
	shutdown_power_off();
}

int read(int fd, void *buffer, unsigned size){
	int k=0;
	
	if(fd == 0){
		for(k = 0; k<(int)size; k++){
			*((char*)buffer+k)= input_getc();
			if(*((char*)buffer+k) == '\0') {
				return k;
			}
		}
//	if(CHECK_S) printf("~~read 2(RETURN) (2)\n");
		return k;
	}
	///project #2 ///////////////////////////////////////////////
	else if (fd >=3 && fd<128) {
		if(thread_current()->f_list[fd].file == NULL) return -1;

		int j;
		if(buffer>=PHYS_BASE) exit(-1);	
		lock_acquire(&sys_lock); 
		j =  file_read(thread_current()->f_list[fd].file, buffer, size);
		if(CHECK_S) printf("READ fd=%d name=%s return=%d",fd,thread_current()->f_list[fd].name,j);
		lock_release(&sys_lock);
		return j;
	}
	///project #2 /////////////////////////////////////////////
	else return -1;
//	if(CHECK_S) printf("~~read 2(RETURN) -1\n");

}

int write (int fd, const void *buffer , unsigned size){
	if(fd == 1){
		putbuf(buffer,size);
		return (int)size;
	}
	///project #2 ////////////////////////////////////////
	else if(fd>=3 && fd<128){

	if(thread_current()->f_list[fd].file == NULL) return -1;
	
	int j;
	lock_acquire(&sys_lock);
	j = file_write(thread_current()->f_list[fd].file, buffer, size);
	if(CHECK_S) printf("WRITE fd=%d name=%s return=%d",fd,thread_current()->f_list[fd].name,j);
	lock_release(&sys_lock);
	return j;
	}
	///project #2 ///////////////////////////////////

	else {
		if(CHECK_S) printf("~~write 2(RETURN) -1\n");
		return -1;
	}
}

void exit(int status){
  struct thread *cur, *cur_parent; //cur : target to exit
  char thread_name_copy[128];	//these
  char *thread_token;		//are
  char *temp_thread_token;	//for print
  int i=0;

  cur=thread_current();
  cur_parent=cur->parent;
  if(CHECK_S) printf("EXIT tid %d\n",cur->tid);

  //print
  strlcpy(thread_name_copy,cur->name,strlen(cur->name)+1);
  thread_token=strtok_r(thread_name_copy," ",&temp_thread_token);
  printf("%s: exit(%d)\n", thread_token, status); //29p,3-3-2

  //settings
  cur_parent->value=status;
  cur_parent->waiting++;	//wait done
  cur->by_exit=1;
  
  //exit
  if(CHECK_S) printf("     start thread_exit()\n");
   thread_exit();

}

int exec (const char *cmd_line){
  if(CHECK_S) printf("EXEC tid %d\n",thread_current()->tid);
  return process_execute(cmd_line);
}

int wait(pid_t pid){
  if(CHECK_S) printf("WAIT tid %d\n",thread_current()->tid);
  return process_wait(pid);
}

int sum_of_four_integers (int a, int b, int c, int d){
  return a+b+c+d;
}

int pibonacci (int n){
  int a1, a2;
  int i;

  a1=0;
  a2=1;

  for(i=0;i<n;i++){
    a2=a1+a2;
    a1=a2-a1;
  }
  return a1;
}


//////////////Project 2/////////////////////

bool remove(const char *file){
	return filesys_remove(file);
}

bool create(const char *file, unsigned initial_size){
	if(file == NULL) exit(-1);
	return filesys_create(file, initial_size);	
}
int filesize(int fd){	
	return file_length(thread_current()->f_list[fd].file);	
}
void seek(int fd, unsigned position){
	file_seek(thread_current()->f_list[fd].file, position);
	return;
}
unsigned tell(int fd){
	return file_tell(thread_current()->f_list[fd].file);
}

int open(const char* file){
	struct thread *cur = thread_current();
	struct file* f;
	if (cur == NULL) return -1;
	if (file == NULL) return -1;
	
	f = filesys_open(file);
	if (f == NULL) return -1;
	
	int k;
	for(k = 3; k<128; k++){
		if(cur->f_list[k].id != 1){
			cur->f_list[k].id = 1;
			cur->f_list[k].file = f;
			strlcpy(cur->f_list[k].name, file, strlen(file)+1);
			//cur->f_idx = k;
			if(CHECK_S) printf("OPEN %s in thread %d",cur->f_list[k].name,cur->tid);
			return k;
		}
	}
	return -1;
}

void close(int fd){
	struct thread *cur = thread_current();
	
	cur->f_list[fd].id = 0;
	cur->f_list[fd].file = NULL;
	if (CHECK_S) printf("CLOSE %s in thread %d",cur->f_list[fd].name,cur->tid);

	file_close(cur->f_list[fd].file);
	return;
}









