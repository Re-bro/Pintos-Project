#ifndef USERPROG_SYSCALL_H
#define USERPROG_SYSCALL_H
#include "filesys/off_t.h"
#include "threads/thread.h"

void syscall_init (void);
void halt(void);
int read(int,void*,unsigned);
int write(int,const void*,unsigned);
void exit(int);
int exec(const char*);
int wait(pid_t);
int sum_of_four_integers(int,int,int,int);
int pibonacci(int);
void seek(int, unsigned);
unsigned tell(int);
int filesize(int);
bool remove(const char*);
bool create(const char*, unsigned);
int open(const char*);
void close(int);
#endif /* userprog/syscall.h */
